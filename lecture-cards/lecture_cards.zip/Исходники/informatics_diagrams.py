"""Vector illustrations for the ten transcript-based graph lecture cards.

Only graph_table and matrix reproduce the explicitly spoken four-city data.
All other graphs are small explanatory examples, not reconstructions of unseen
lecture slides. Callbacks use the render_engine DIAGRAMS contract.
"""
import math
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

BG = '#fdfcf7'
CITY_NAMES = ['А', 'М', 'О', 'С']
CITY_EDGES = [(0,1,3),(0,2,1),(0,3,5),(1,2,2),(1,3,1),(2,3,4)]
CITY_MATRIX = [[None,3,1,5],[3,None,2,1],[1,2,None,4],[5,1,4,None]]

def _font():
    for name, file in [('sans','DejaVuSans.ttf'),('sansb','DejaVuSans-Bold.ttf')]:
        if name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))

class Draw:
    def __init__(self,c,x,y,w,h,p):
        _font();self.c=c;self.x=x;self.y=y;self.w=w;self.h=h;self.p=p
    def point(self,a,b):return self.x+a*self.w,self.y+b*self.h
    def txt(self,s,a,b,size=24,bold=False,color=None,align='center'):
        c=self.c;c.setFillColor(HexColor(color or self.p['ink']));c.setFont('sansb' if bold else 'sans',size)
        xx,yy=self.point(a,b)
        getattr(c,{'left':'drawString','center':'drawCentredString','right':'drawRightString'}[align])(xx,yy,str(s))
    def line(self,a,b,d,e,color=None,width=2.3,dash=None):
        c=self.c;c.setStrokeColor(HexColor(color or self.p['line']));c.setLineWidth(width);c.setDash(dash or [])
        c.line(*self.point(a,b),*self.point(d,e));c.setDash([])
    def node(self,name,a,b,r=22,accent=False):
        c=self.c;c.setFillColor(HexColor(self.p['accent'] if accent else self.p['pale']));c.setStrokeColor(HexColor(self.p['accent']));c.setLineWidth(2)
        c.circle(*self.point(a,b),r,stroke=1,fill=1)
        self.txt(name,a,b-8/self.h,24,True,BG if accent else self.p['accent'])
    def pill(self,s,a,b,w=120,h=47,size=25):
        xx,yy=self.point(a,b);c=self.c;c.setFillColor(HexColor(self.p['pale']));c.setStrokeColor(HexColor(self.p['line']));c.setLineWidth(1.3)
        c.roundRect(xx-w/2,yy-h/2,w,h,8,stroke=1,fill=1);self.txt(s,a,b-size*.32/self.h,size,True,self.p['accent'])
    def weight(self,n,a,b):
        xx,yy=self.point(a,b);self.c.setFillColor(HexColor(BG));self.c.roundRect(xx-16,yy-17,32,34,5,stroke=0,fill=1)
        self.txt(n,a,b-8/self.h,24,False,self.p['ink'])
    def arrow(self,a,b,d,e,color=None):
        color=color or self.p['accent'];self.line(a,b,d,e,color,2.5)
        xx,yy=self.point(d,e);sx,sy=self.point(a,b);angle=math.atan2(yy-sy,xx-sx);z=10
        c=self.c;c.setFillColor(HexColor(color));path=c.beginPath();path.moveTo(xx,yy)
        for ang in [angle-.43,angle+.43]:path.lineTo(xx-z*math.cos(ang),yy-z*math.sin(ang))
        path.close();c.drawPath(path,stroke=0,fill=1)
    def sub(self,a,b,w,h):
        xx,yy=self.point(a,b);return Draw(self.c,xx,yy,self.w*w,self.h*h,self.p)

def _cities(d, labels=CITY_NAMES, weights=True):
    pts=[(.09,.82),(.91,.82),(.50,.13),(.50,.56)]
    for i,j,n in CITY_EDGES:
        a,b=pts[i];e,f=pts[j];d.line(a,b,e,f)
        if weights:d.weight(n,(a+e)/2,(b+f)/2)
    for name,(a,b) in zip(labels,pts):d.node(name,a,b)

def _matrix(d,labels=CITY_NAMES,values=CITY_MATRIX):
    n=4;cell=min(d.w/5,d.h/5);ox=d.x+(d.w-5*cell)/2;oy=d.y+(d.h-5*cell)/2
    c=d.c;c.setLineWidth(1.1)
    for row in range(5):
        for col in range(5):
            xx=ox+col*cell;yy=oy+(4-row)*cell
            c.setFillColor(HexColor(d.p['pale'] if row==0 or col==0 or row==col else BG));c.setStrokeColor(HexColor(d.p['line']));c.rect(xx,yy,cell,cell,stroke=1,fill=1)
            if not row and not col:continue
            s=labels[col-1] if row==0 else labels[row-1] if col==0 else '—' if values[row-1][col-1] is None else str(values[row-1][col-1])
            c.setFont('sansb' if not row or not col else 'sans',24);c.setFillColor(HexColor(d.p['accent'] if not row or not col else d.p['ink']));c.drawCentredString(xx+cell/2,yy+cell/2-8,s)

def graph_table(d,card):
    _cities(d.sub(.00,.16,.49,.83));_matrix(d.sub(.59,.16,.39,.83))
    d.arrow(.51,.56,.57,.56)
    d.txt('А — Анадырь   М — Москва   О — Омск   С — СПб',.5,.025,24)

def matrix(d,card):
    _matrix(d.sub(.01,.02,.38,.96))
    d.txt('А → М: 3',.66,.78,29,True,d.p['accent'])
    d.txt('М → А: тоже 3',.66,.55,25)
    d.pill('aᵢⱼ = aⱼᵢ',.66,.29,210,54,29)
    d.txt('Прямой дороги нет → пустая клетка',.67,.035,23)

def degree(d,card):
    pts=[(.09,.73),(.09,.20),(.40,.73),(.40,.20)]
    for a,b in pts:d.line(.245,.47,a,b,d.p['accent'],3)
    for label,(a,b) in zip(['Б','В','Г','Д'],pts):d.node(label,a,b)
    d.node('А',.245,.47,27,True)
    d.txt('4 ребра',.245,.02,25,True,d.p['accent'])
    d.pill('d(А) = 4',.72,.68,230,64,32)
    for i,s in enumerate(['●','●','●','●']):d.pill(s,.58+i*.093,.32,59,47,23)
    d.txt('Считаем связи, а не сумму весов',.72,.07,23)

def neighbor_signature(d,card):
    # Complete illustrative graph: B,C,D have exact degrees 2,3,4.
    g=d.sub(.01,.10,.61,.87);pts=[(.07,.51),(.35,.87),(.35,.51),(.35,.15),(.67,.87),(.69,.35),(.94,.15)]
    edges=[(0,1),(0,2),(0,3),(1,4),(2,4),(2,5),(3,4),(3,5),(3,6)]
    for i,j in edges:g.line(*pts[i],*pts[j],color=d.p['accent'] if i==0 else '#8db6ad',width=2.9 if i==0 else 1.7)
    for i,(a,b) in enumerate(pts):g.node('АБВГДЕЖ'[i],a,b,21,accent=i==0)
    for i,degree_ in [(1,2),(2,3),(3,4)]:
        a,b=pts[i];g.txt('d='+str(degree_),a-.13,b-9/g.h,23,True,d.p['accent'])
    d.txt('Соседи А:',.81,.77,25,True,d.p['accent'])
    d.txt('2, 3, 4',.81,.56,29)
    d.arrow(.74,.43,.88,.43)
    d.pill('234',.81,.23,185,64,34)
    d.txt('Степень самой А = 3',.31,.025,23)

def matching_groups(d,card):
    d.txt('Одинаковая группа кандидатов',.29,.88,24,True,d.p['accent'])
    d.line(.12,.42,.43,.65,d.p['accent'],3);d.node('К',.12,.42,25,True);d.node('А',.43,.65);d.node('Б',.43,.17)
    d.txt('известна',.12,.19,23);d.txt('ребра нет',.29,.085,23)
    d.line(.54,.05,.54,.93,width=1.2)
    d.txt('Смотрим связь с К',.77,.82,26,True,d.p['accent'])
    d.pill('Кандидат 1: есть',.77,.54,330,55,24)
    d.pill('Кандидат 2: нет',.77,.24,330,55,24)

def symmetry(d,card):
    d.line(.08,.55,.31,.55,d.p['accent'],3);d.line(.31,.55,.54,.55,d.p['accent'],3)
    d.node('А',.08,.55);d.node('О',.31,.55,25,True);d.node('Б',.54,.55)
    d.weight(9,.195,.55);d.weight(12,.425,.55)
    d.arrow(.11,.27,.51,.27);d.arrow(.51,.14,.11,.14)
    d.txt('А и Б могут поменяться местами',.31,.85,23)
    d.line(.61,.07,.61,.92,width=1.2)
    d.txt('Отдельные дороги:',.81,.78,24,True,d.p['accent'])
    d.txt('9 или 12',.81,.57,29)
    d.pill('9 + 12 = 21',.81,.28,270,62,29)

def missing_edge(d,card):
    pts=[(.08,.66),(.40,.66),(.40,.16),(.08,.16)]
    for i,j in [(0,3),(3,2),(2,1)]:d.line(*pts[i],*pts[j])
    d.line(*pts[0],*pts[1],d.p['accent'],2.8,[7,5]);d.weight('?',.24,.66)
    for name,(a,b) in zip(['А','Б','В','Г'],pts):d.node(name,a,b)
    d.txt('Удалённое ребро А–Б',.24,.88,24,True,d.p['accent'])
    d.line(.50,.05,.50,.94,width=1.2)
    d.txt('Меняются только его концы',.75,.80,23,True,d.p['accent'])
    d.pill('d(А): 2 → 1',.75,.54,280,54,27)
    d.pill('d(Б): 2 → 1',.75,.25,280,54,27)
    d.txt('d(В) и d(Г) сохраняются',.75,.025,23)

def redraw(d,card):
    # Same unweighted K4 topology; number/letter pairing is illustrative.
    _cities(d.sub(.00,.08,.41,.86),labels=['1','2','3','4'],weights=False)
    d.arrow(.445,.52,.545,.52)
    # Different arrangement: transpose the two top vertices and rotate a third.
    g=d.sub(.59,.08,.41,.86);pts=[(.84,.82),(.09,.54),(.63,.11),(.53,.64)]
    for i,j,n in CITY_EDGES:g.line(*pts[i],*pts[j])
    for name,(a,b) in zip(['А','Б','В','Г'],pts):g.node(name,a,b)
    d.txt('Места вершин меняются. Связи остаются.',.5,.025,24,True,d.p['accent'])

def enumeration(d,card):
    for a,e in [(.10,.26),(.26,.42)]:d.line(a,.70,e,.70,d.p['accent'],3)
    for a,n in zip([.10,.26,.42],['1','2','3']):d.node(n,a,.70)
    for a,e in [(.61,.77),(.77,.93)]:d.line(a,.70,e,.70,d.p['accent'],3)
    for a,n in zip([.61,.77,.93],['А','Б','В']):d.node(n,a,.70)
    d.arrow(.47,.70,.56,.70)
    d.pill('1→А, 2→Б, 3→В',.25,.26,380,61,25)
    d.pill('1→В, 2→Б, 3→А',.75,.26,380,61,25)
    d.txt('Оба соответствия сохраняют все ребра',.5,.025,24,True,d.p['accent'])

def algorithm(d,card):
    steps=[('Степени','сколько связей'),('Соседи','какие степени'),('Связи','с кем соединён'),('Ответ','нужная клетка')]
    for i,(heading,caption) in enumerate(steps):
        a=.115+.255*i
        d.pill(heading,a,.59,184,65,26)
        d.txt(caption,a,.23,23)
        if i<3:d.arrow(a+.110,.59,a+.145,.59)

def _callback(fn):
    def callback(c,x,y,w,h,palette,card):
        c.saveState();path=c.beginPath();path.rect(x,y,w,h);c.clipPath(path,stroke=0,fill=0)
        fn(Draw(c,x,y,w,h,palette),card);c.restoreState()
    return callback

DIAGRAMS = {name:_callback(fn) for name,fn in {
    'graph_table':graph_table,'matrix':matrix,'degree':degree,
    'neighbor_signature':neighbor_signature,'matching_groups':matching_groups,
    'symmetry':symmetry,'missing_edge':missing_edge,'redraw':redraw,
    'enumeration':enumeration,'algorithm':algorithm,
}.items()}

def register(engine):
    engine.DIAGRAMS.update(DIAGRAMS)

register_diagrams = register

if __name__ == '__main__':
    from pathlib import Path
    from reportlab.pdfgen import canvas
    import fitz
    out=Path('/workspace/cards/output');out.mkdir(exist_ok=True)
    palette={'ink':'#152031','accent':'#006b68','pale':'#e9f7f1','line':'#40988d'}
    path=out/'informatics_diagrams_preview.pdf';c=canvas.Canvas(str(path),pagesize=(1050,1500))
    for name,cb in DIAGRAMS.items():
        c.setFillColor(HexColor(BG));c.rect(0,0,1050,1500,fill=1,stroke=0)
        Draw(c,39,1420,972,30,palette).txt(name,.0,.0,25,True,align='left')
        cb(c,39,1100,972,255,palette,{})
        c.showPage()
    c.save();doc=fitz.open(path)
    for i in range(len(doc)):doc[i].get_pixmap(matrix=fitz.Matrix(.8,.8)).save(str(out/f'informatics_diagram_{i+1:02}.png'))
