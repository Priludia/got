"""Сборка учебных карточек по транскрипциям. python build_cards.py"""
from pathlib import Path
import json
import fitz
import render_engine as engine
from physics_diagrams import draw_diagram

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output'

for key in ('circle', 'angular', 'rigid', 'latitude', 'belt', 'period', 'normal', 'pendulum', 'centrifuge', 'rolling'):
    engine.DIAGRAMS[key] = lambda c,x,y,w,h,p,card,k=key: draw_diagram(c,k,x,y,w,h,p)

def build():
    from informatics_diagrams import register_diagrams
    register_diagrams(engine)
    results = {}
    for subject, stem in [('physics', 'Физика_карточки'), ('informatics', 'Информатика_карточки')]:
        cards = json.loads((ROOT / (subject+'_plan.json')).read_text())
        result = engine.render_deck(cards, OUT/(stem+'.pdf'), subject, OUT/(subject+'_png'))
        engine.make_contact_sheet(result['pngs'], OUT/(subject+'_preview.png'), columns=5)
        results[subject] = result
    combined = fitz.open()
    for result in results.values():
        with fitz.open(result['pdf']) as doc:
            combined.insert_pdf(doc)
    combined.set_metadata({'title':'Учебные карточки по лекциям — физика и информатика', 'author':'Учебные карточки'})
    combined.save(OUT/'Все_карточки.pdf', garbage=4, deflate=True)
    (OUT/'validation.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps({s:{'pages':len(r['pngs']),'warnings':r['warnings']} for s,r in results.items()},ensure_ascii=False,indent=2))

if __name__ == '__main__':
    build()
