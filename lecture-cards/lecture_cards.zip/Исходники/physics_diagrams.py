"""Scientifically checked vector schematics for the physics cards.

All coordinates passed to draw_diagram are ReportLab native lower-left coordinates.
The drawing is clipped to the provided rectangle and uses the engine's palette.
"""
import math
from reportlab.lib import colors as rlcolors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont


def draw_diagram(c, kind, x, y, w, h, colors=None, fonts=None):
    palette = colors or {}
    if not isinstance(palette, dict):
        palette = {}
    green = palette.get('green', palette.get('accent', rlcolors.HexColor('#07572d')))
    ink = palette.get('ink', palette.get('text', rlcolors.HexColor('#20201e')))
    pale = palette.get('pale', rlcolors.HexColor('#eef2e6'))
    font = (fonts or {}).get('body', 'DiagramSans') if isinstance(fonts, dict) else 'DiagramSans'
    if font not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('DiagramSans', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
        font = 'DiagramSans'
    fs = max(9, min(24, w / 38))
    line = max(1.0, w / 600)
    def P(a,b): return x + a*w, y + b*h
    def label(a,b,s,align='left',color=ink,size=None):
        c.setFillColor(color); c.setFont(font,size or fs)
        xx,yy=P(a,b)
        if align=='center': c.drawCentredString(xx,yy,s)
        elif align=='right': c.drawRightString(xx,yy,s)
        else: c.drawString(xx,yy,s)
    def segment(a,b,d,e,color=ink,dash=None):
        c.setStrokeColor(color); c.setLineWidth(line)
        c.setDash(dash or [])
        c.line(*P(a,b),*P(d,e)); c.setDash([])
    def arrow(a,b,d,e,color=green):
        segment(a,b,d,e,color)
        xx,yy=P(d,e); sx,sy=P(a,b)
        theta=math.atan2(yy-sy,xx-sx); z=max(5,min(12,w/85))
        p=c.beginPath(); p.moveTo(xx,yy)
        p.lineTo(xx-z*math.cos(theta-.45),yy-z*math.sin(theta-.45))
        p.lineTo(xx-z*math.cos(theta+.45),yy-z*math.sin(theta+.45));p.close()
        c.setFillColor(color);c.drawPath(p,fill=1,stroke=0)
    def circle(a,b,r,fill=False,color=ink):
        xx,yy=P(a,b); c.setStrokeColor(color);c.setLineWidth(line)
        c.setFillColor(pale);c.circle(xx,yy,r*h,stroke=1,fill=int(fill))
    def dot(a,b): circle(a,b,max(.015,3/h),True)
    def arc(a,b,r,t1,t2,arrow_end=False,color=green):
        xx,yy=P(a,b); rr=r*h
        c.setStrokeColor(color);c.setLineWidth(line)
        c.arc(xx-rr,yy-rr,xx+rr,yy+rr,t1,t2-t1)
        if arrow_end:
            ang=math.radians(t2); end=(a+rr/w*math.cos(ang),b+r*math.sin(ang))
            before=math.radians(t2-(4 if t2>t1 else -4))
            st=(a+rr/w*math.cos(before),b+r*math.sin(before))
            arrow(*st,*end,color)
    def circle_point(a,b,r,t):
        t=math.radians(t);return a+r*h/w*math.cos(t),b+r*math.sin(t)
    def captions(lines,a=.58,b=.72,step=.2):
        for i,s in enumerate(lines):
            available=(.97-a)*w
            fitted=min(fs,fs*available/max(1,pdfmetrics.stringWidth(s,font,fs)))
            label(a,b-step*i,s,size=fitted)
    def axes(a=.12,b=.15,d=.48,e=.88):
        arrow(a,b,d,b,ink);arrow(a,b,a,e,ink)
    c.saveState()
    clip=c.beginPath();clip.rect(x,y,w,h);c.clipPath(clip,stroke=0,fill=0)
    k=kind.lower().replace('_','').replace('-','')
    if k in ('geometry','circulargeometry','arc','circle'):
        a,b,r=.25,.47,.36;circle(a,b,r)
        p=circle_point(a,b,r,55);segment(a,b,*p,green);segment(a,b,*circle_point(a,b,r,0))
        arc(a,b,r,0,55,True);arc(a,b,.12,0,55)
        dot(a,b);dot(*p);label(a-.015,b-.11,'O');label(a+.04,b+.045,'φ');label(p[0]-.07,p[1]-.13,'R')
        t=math.radians(55);q=(p[0]-.22*h/w*math.sin(t),p[1]+.22*math.cos(t))
        arrow(*p,*q);label(q[0]-.025,q[1]+.005,'v')
        captions(['Дуга: s = Rφ','Скорость — по касательной','φ измеряем в радианах'])
    elif k in ('period','turn','periodfreq'):
        a,b,r=.25,.49,.32;circle(a,b,r);arc(a,b,r,25,335,True);dot(*circle_point(a,b,r,0))
        label(a,b-.025,'T',align='center',color=green,size=fs*1.6)
        captions(['Один оборот: 2π рад','T — время одного оборота','ν — число оборотов в секунду'])
    elif k=='rigid':
        a,b=.20,.43;inner=.175;outer=.35;theta=math.radians(30)
        circle(a,b,inner);circle(a,b,outer)
        p=circle_point(a,b,inner,30);q=circle_point(a,b,outer,30)
        segment(a,b,*q);dot(*p);dot(*q);dot(a,b)
        # Two tangents with an exact 2:1 physical length ratio.
        tangent=(-math.sin(theta), math.cos(theta))
        ep=(p[0]+tangent[0]*.15*h/w,p[1]+tangent[1]*.15)
        eq=(q[0]+tangent[0]*.30*h/w,q[1]+tangent[1]*.30)
        arrow(*p,*ep);arrow(*q,*eq)
        label(p[0]+.015,p[1]-.075,'B');label(q[0]+.02,q[1]-.05,'A')
        label(ep[0]-.04,ep[1]+.02,'vB',color=green);label(eq[0]+.015,eq[1]+.02,'vA',color=green)
        captions(['У всех точек одна ω','rB = rA/2 → vB = vA/2','Дальше от оси → быстрее'])
    elif k=='latitude':
        a,b,r=.24,.48,.36;circle(a,b,r)
        # Meridional view: Earth rotation axis and parallel at latitude 60°.
        segment(a,.06,a,.94,dash=[4,3]);segment(a-r*h/w,b,a+r*h/w,b,dash=[4,3])
        p=circle_point(a,b,r,60);q=(a,p[1]);segment(a,b,*p,green);segment(*q,*p,green)
        dot(*p);dot(a,b);arc(a,b,.14,0,60);label(a+.025,b+.045,'60°')
        label((q[0]+p[0])/2,p[1]+.045,'r',align='center',color=green);label(a-.055,.91,'ось')
        label(a+.085,b+.16,'R');label(a+.12,b-.035,'экватор',size=fs*.8)
        captions(['На всех широтах одна ω','r = R cos 60° = R/2','v₆₀ = ωr = vэкв/2'])
    elif k in ('belt','pulleys'):
        # An open belt: the exact common external tangents preserve contact.
        a,b,r1,r2=.17,.48,.25,.35;d=.27*w;rho1=r1*h;rho2=r2*h
        theta=math.acos((rho1-rho2)/d)
        circle(a,b,r1);circle(a+.27,b,r2)
        for t in [theta,-theta]:
            p=(a+rho1/w*math.cos(t),b+r1*math.sin(t));q=(a+.27+rho2/w*math.cos(t),b+r2*math.sin(t));segment(*p,*q,green)
        arc(a,b,.13,170,25,True);arc(a+.27,b,.19,170,25,True)
        label(a,.07,'R₁',align='center');label(a+.27,.07,'R₂',align='center');label(.3,.87,'v ремня',align='center',color=green)
        captions(['Без проскальзывания','ω₁R₁ = ω₂R₂','Больший шкив вращается медленнее'])
    elif k in ('normal','acceleration'):
        a,b,r=.23,.47,.33;circle(a,b,r);p=circle_point(a,b,r,35);dot(*p);dot(a,b)
        arrow(*p,a,b);label(a+.015,b+.065,'aₙ',color=green)
        tangent=(-math.sin(math.radians(35)),math.cos(math.radians(35)))
        q=(p[0]+tangent[0]*h*.3/w,p[1]+tangent[1]*.3)
        arrow(*p,*q);label(q[0]-.035,q[1]-.02,'v' if k=='normal' else 'aτ',color=green)
        if k=='acceleration':
            normal=(-math.cos(math.radians(35)), -math.sin(math.radians(35)))
            end=(p[0]+(normal[0]*.33+tangent[0]*.3)*h/w,p[1]+normal[1]*.33+tangent[1]*.3)
            arrow(*p,*end,ink);label(end[0]-.035,end[1]+.02,'a')
            captions(['aₙ меняет направление v','aτ меняет модуль v','Полное ускорение — векторная сумма'])
        else:captions(['v — вдоль касательной','aₙ — к центру окружности','v перпендикулярна aₙ'])
    elif k=='derivative':
        cols=[.12,.43,.75];texts=[('φ(t)','угол'),('ω(t)','угловая скорость'),('ε(t)','угловое ускорение')]
        for a,(top,bottom) in zip(cols,texts):
            label(a,.59,top,align='center',size=fs*1.4,color=green);label(a,.22,bottom,align='center')
        for a,d in [(.21,.34),(.53,.65)]:
            arrow(a,.60,d,.60);label((a+d)/2,.79,'d/dt',align='center')
    elif k in ('constangular','omega','angularlaw','angular'):
        axes();segment(.12,.15,.44,.77,green);label(.10,.91,'φ');label(.5,.13,'t');label(.09,.09,'0');label(.29,.77,'ω = const',align='center',color=green)
        captions(['φ(t) = φ₀ + ωt','ω = Δφ / Δt','Угол меняется линейно со временем'])
    elif k=='meetings':
        a,b,r=.26,.48,.32;circle(a,b,r)
        for t,txt in [(40,'1'),(220,'2')]:
            p=circle_point(a,b,r,t);dot(*p);label(p[0]+.015,p[1]+.025,txt)
        arc(a,b,.32,48,125,True);arc(a,b,.32,212,145,True)
        captions(['Навстречу: ωотн = ω₁ + ω₂','В одну сторону: ωотн = |ω₁ − ω₂|','Встреча: Δφотн = 2πk'])
    elif k in ('rollingvelocity','rollingpoints','rolling'):
        a,b,r=.24,.48,.32;circle(a,b,r);segment(.06,b-r,.48,b-r)
        top=(a,b+r);bottom=(a,b-r);dot(*top);dot(*bottom);dot(a,b)
        arrow(a,b,a+.15,b);arrow(*top,top[0]+.30,top[1]);label(a+.31,b+r+.04,'2v',color=green)
        label(a+.16,b+.035,'v',color=green);label(a+.035,b-r-.13,'0');arc(a,b,.21,140,20,True)
        side=(a+r*h/w,b);dot(*side);arrow(*side,side[0]+.06,side[1]-.06*w/h)
        label(side[0]+.07,side[1]-.06*w/h,'vбок',color=green,size=fs*.85)
        captions(['Качение: v центра = ωR','Сверху: 2v;  снизу: 0','Сбоку: скорость под 45° к горизонту'])
    elif k=='rollingcenter':
        a,b,r=.25,.46,.30;circle(a,b,r);segment(.06,b-r,.48,b-r);dot(a,b);dot(a,b-r)
        arrow(a,b,a+.17,b);label(a+.18,b+.02,'v центра',color=green)
        segment(a,b,a,b-r);label(a-.04,b-.18,'R');arc(a,b,.22,150,20,True)
        label(a+.03,b+.23,'ω',color=green)
        captions(['Поступательное движение центра','Вращение вокруг центра','Условие качения: v = ωR'])
    elif k in ('centrifuge','centrifugenumeric'):
        a,b,r=.24,.47,.32;circle(a,b,r);dot(a,b);p=circle_point(a,b,r,0);dot(*p)
        arrow(*p,a,b);label(a+.025,b+.045,'aₙ',color=green)
        arrow(*p,p[0],p[1]+.14);label(p[0]+.015,p[1]+.10,'aτ',color=green)
        arrow(p[0]+.08,p[1],p[0]+.08,p[1]+.32,ink);label(p[0]+.10,p[1]+.28,'v')
        captions(['R = 50 м;  v = 2t','При t = 60 с: v = 120 м/с','aτ = 2 м/с²;  aₙ = 288 м/с²'])
        label(.23,.03,'Векторы показаны схематично',align='center',size=fs*.72)
    elif k=='rollingaccel':
        a,b,r=.25,.47,.32;circle(a,b,r);segment(.06,b-r,.47,b-r)
        for t in [0,90,180,270]:
            p=circle_point(a,b,r,t);dot(*p)
            q=(p[0]+(a-p[0])*.70,p[1]+(b-p[1])*.70);arrow(*p,*q)
        dot(a,b);label(a+.035,b-.03,'O');label(a+.10,.85,'aₙ = ω²R',color=green)
        captions(['При постоянной скорости центра','aO = 0;  ε = 0','Ускорение точек направлено к O'])
    elif k=='curvature':
        # Exact parabola and its osculating circle at the apex.
        a,b=.27,.68;rr=.48*h
        c.setStrokeColor(ink);c.setLineWidth(line)
        p=c.beginPath()
        for i in range(101):
            dx=(-.26+.52*i/100)*w;yy=b*h-dx*dx/(2*rr)
            if i==0:p.moveTo(x+a*w+dx,y+yy)
            else:p.lineTo(x+a*w+dx,y+yy)
        c.drawPath(p)
        c.setDash([4,4]);circle(a,b-.48,.48,color=green);c.setDash([])
        dot(a,b);arrow(a,b,a+.15,b);arrow(a,b,a,b-.35);label(a+.16,b+.015,'v');label(a+.015,b-.24,'aₙ = g',color=green)
        captions(['В вершине траектории v ⟂ g','Радиус кривизны: ρ = v²/aₙ','Для вершины: ρ = v²/g'])
    elif k=='pendulum':
        # Extreme left and lowest positions, each annotated independently.
        a,b=.25,.90;l=.55;ang=35
        bottom=(a,b-l);left=circle_point(a,b,l,270-ang)
        segment(a,b,*bottom,dash=[3,3]);segment(a,b,*left);dot(a,b)
        arc(a,b,l,270-ang,270+ang,color=ink)
        circle(*left,.035,True);circle(*bottom,.035,True)
        # At left endpoint tangent acceleration points down/right toward bottom.
        tx,ty=math.cos(math.radians(ang)),-math.sin(math.radians(ang))
        q=(left[0]+tx*.28*h/w,left[1]+ty*.28);arrow(*left,*q)
        label(left[0]-.085,left[1]-.03,'aτ',color=green)
        arrow(*bottom,a,bottom[1]+.29);label(a+.02,bottom[1]+.19,'aₙ',color=green)
        label(left[0]-.09,left[1]-.11,'v = 0',size=fs*.83)
        label(bottom[0]+.035,bottom[1]-.11,'vмакс',size=fs*.83)
        captions(['В крайней точке: aₙ = 0','В нижней точке: aτ = 0','Между ними есть обе составляющие'])
    elif k=='conical':
        a,b=.25,.87;dot(a,b);p=(a+.10,.3);segment(a,b,*p);segment(a,b,a,.3,dash=[4,3]);dot(*p)
        arc(a,b,.2,270,math.degrees(math.atan2((p[1]-b)*h,(p[0]-a)*w)));label(a+.014,.6,'α')
        arrow(*p,a+.034,.68);label(a+.055,.58,'N',color=green);arrow(*p,p[0],.04);label(p[0]+.015,.08,'mg')
        # Horizontal orbit projected as an ellipse.
        c.setStrokeColor(ink);c.setDash([3,3]);c.ellipse(*P(a-.10,.23),*P(a+.10,.37));c.setDash([])
        segment(a,.3,*p);label(a+.035,.19,'r')
        captions(['Вертикально: N cos α = mg','К оси: N sin α = mv²/r','Центр окружности — под подвесом'])
    elif k=='frictioncentrifuge':
        a,b,r=.24,.46,.33;circle(a,b,r);dot(a,b);p=circle_point(a,b,r,0);dot(*p);arrow(*p,a,b)
        label(a+.01,b+.07,'Fтр',color=green);arc(a,b,.25,50,160,True)
        captions(['Вид сверху: вращающийся диск','Трение покоя направлено к оси','Fтр ≤ μN;  N = mg'])
    elif k in ('bridge','sphere'):
        a,b=.27,.27;radius=.57
        arc(a,b,radius,20,160,color=ink);p=(a,b+radius);dot(*p)
        arrow(*p,a,.49);label(a+.015,.55,'mg');arrow(*p,a,.98);label(a+.015,.93,'N',color=green)
        arrow(a-.10,p[1],a-.10,.5);label(a-.19,.53,'aₙ',color=green)
        captions(['В вершине выпуклой поверхности','mg − N = mv²/R','Отрыв происходит при N = 0'])
    else:
        captions(['Движение по окружности','v = ωR','aₙ = v²/R'],a=.24)
    c.restoreState()
