"""Six complete worked-task cards in the existing light informatics style."""
from pathlib import Path
import sys, json, html, math
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import render_engine as e
from reportlab.pdfgen import canvas
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.colors import HexColor
import fitz

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'
P=e.PALETTES['informatics']
TITLES={2:'Задача 1:\nдлина дороги',9:'Задача 2:\nсумма дорог',39:'Задача 3:\nсимметрия и сумма',23:'Задача 4:\nпропущенная дорога',21:'Задача 5:\nперерисовка графа',38:'Задача 6:\nперебор соответствий'}
QUESTIONS={2:'Найдите длину дороги БГ.',9:'Найдите сумму длин дорог BH и AE.',39:'Найдите сумму длин дорог ГЕ и ДЗ.',23:'На рисунке пропущена одна дорога. Найдите её длину.',21:'Найдите сумму длин дорог ED и CA.',38:'Найдите длину дороги ВЕ.'}

def measure(s,size,w):
    para=Paragraph(html.escape(s).replace('\n','<br/>'),ParagraphStyle('m',fontName='sans',fontSize=size,leading=size*1.25))
    return para.wrap(w,10000)[1]

def matrix(c,card,x,top,side):
    n=max(max(a,b) for a,b,_ in card['matrix_edges']);cell=side/(n+1)
    targets={2:{(6,8)},9:{(1,6),(5,8)},39:{(2,7),(1,6)},23:{(4,7)},21:{(3,7),(4,5)},38:{(4,6)}}[card['number']]
    values={}
    for a,b,v in card['matrix_edges']:values[a,b]=v;values[b,a]=v
    degrees={i:sum(1 for a,b,_ in card['matrix_edges'] if i in (a,b)) for i in range(1,n+1)}
    e.text(c,'Таблица из условия',x,top+33,21,'sansb',P['accent'])
    for col in range(1,n+1):
        s=str(degrees[col]);size=21
        xx=x+(col+.5)*cell
        e.text(c,s,xx-e.width(s,'sansb',size)/2,top+7,size,'sansb',P['accent'])
    for row in range(n+1):
        for col in range(n+1):
            xx=x+col*cell;yy=top-(row+1)*cell
            target=tuple(sorted((row,col))) in targets and row and col
            bg=P['pale'] if row==0 or col==0 or target else '#f1f2ef' if row==col else e.BG
            e.fill(c,bg);e.stroke(c,P['line']);c.setLineWidth(1.0);c.rect(xx,yy,cell,cell,fill=1,stroke=1)
            s=('П'+str(col)) if row==0 and col else ('П'+str(row)) if col==0 and row else '—' if row==col and row else str(values.get((row,col),''))
            if not s:continue
            size=22 if n==8 else 23;bold=row==0 or col==0 or target
            font='sansb' if bold else 'sans';color=P['accent'] if bold else P['ink']
            e.text(c,s,xx+(cell-e.width(s,font,size))/2,yy+cell/2-size*.34,size,font,color)
    return top-side

def graph(c,card,x,y,w,h):
    pos=card['graph'].get('positions',card.get('positions'))
    xs=[v[0] for v in pos.values()];ys=[v[1] for v in pos.values()]
    lo,hi=min(xs),max(xs);bottom,up=min(ys),max(ys)
    pts={k:(x+30+(v[0]-lo)/(hi-lo)*(w-60),y+30+(1-(v[1]-bottom)/(up-bottom))*(h-60)) for k,v in pos.items()}
    caption='Граф с найденными номерами' if card['number']==21 else 'Граф из условия'
    e.text(c,caption,x,y+h+64,21,'sansb',P['accent'])
    e.stroke(c,P['accent']);c.setLineWidth(2.4)
    for a,b in card['graph']['edges']:
        c.line(*pts[a],*pts[b])
    for name,(xx,yy) in pts.items():
        e.fill(c,e.BG);e.stroke(c,P['accent']);c.setLineWidth(1.7);c.circle(xx,yy,20,stroke=1,fill=1)
        e.text(c,name,xx-e.width(name,'sansb',27)/2,yy-9,27,'sansb',P['accent'])
        if card['number']==21:
            label='П'+str(card['mappings'][0][name])
            e.text(c,label,xx-e.width(label,'sansb',19)/2,yy-42,19,'sansb',P['accent'])
    degree_boxes=[]
    def hits_segment(rect,a,b):
        t0,t1=0.,1.;dx=b[0]-a[0];dy=b[1]-a[1]
        for p,q in [(-dx,a[0]-rect[0]),(dx,rect[2]-a[0]),(-dy,a[1]-rect[1]),(dy,rect[3]-a[1])]:
            if p==0:
                if q<0:return False
            else:
                u=q/p
                if p<0:t0=max(t0,u)
                else:t1=min(t1,u)
                if t0>t1:return False
        return True
    for name,(xx,yy) in pts.items():
        degree=sum(1 for a,b in card['graph']['edges'] if name in (a,b))
        s=str(degree)
        tw=e.width(s,'sansb',21)
        candidates=[(-tw/2,27),(24,23),(-tw-24,23),(27,-7),(-tw-27,-7),(24,-35),(-tw-24,-35)]
        for dx,dy in candidates:
            box=(xx+dx-3,yy+dy-6,xx+dx+tw+3,yy+dy+19)
            if box[0]<39 or box[2]>1011:continue
            if any(hits_segment(box,pts[a],pts[b]) for a,b in card['graph']['edges']):continue
            if any(not(box[2]<r[0] or box[0]>r[2] or box[3]<r[1] or box[1]>r[3]) for r in degree_boxes):continue
            break
        else:dx,dy=24,23
        degree_boxes.append((xx+dx-3,yy+dy-6,xx+dx+tw+3,yy+dy+19))
        e.text(c,s,xx+dx,yy+dy,21,'sansb',P['accent'])
    # No inferred edge is added to the source graph of task 23.

def hero(c,card,top):
    side=350
    matrix(c,card,43,top-30,side)
    graph(c,card,522,top-321,480,260)
    caption='Над вершинами и столбцами — степени. Длины дорог — в км.'
    e.text(c,caption,43,top-side-62,20,'sans',P['ink'])
    if card['number']==23:
        e.text(c,'В графе пропущена одна дорога.',537,top-356,20,'sansb',P['accent'])
    return top-side-82

def footer(c,card):
    x,y,w,h=32,31,986,112
    e.rounded(c,x,y,w,h,P)
    center=y+h/2
    def centered(s,xx,size,font,color):
        ascent,descent=e.pdfmetrics.getAscentDescent(font,size)
        baseline=center-(ascent+descent)/2
        e.text(c,s,xx,baseline,size,font,color)
    centered('Ответ',x+20,39,'sansb',P['accent'])
    e.stroke(c,P['accent']);c.setLineWidth(2.2);c.line(x+185,y+18,x+185,y+h-18)
    calc=str(card['calculation'])
    # Keep source units separate from the required integer answer.
    value=f"{card['answer']}"
    centered(value,x+208,46,'sansb',P['accent'])
    centered(calc,x+304,25,'sans',P['ink'])

def ordinary_steps(c,card,top):
    steps=card['steps'];bottom=164
    body_size=26
    while body_size>=22:
        needed=[45+measure(s['text'],body_size,972)+18 for s in steps]
        if sum(needed)<=top-bottom:break
        body_size-=.5
    if sum(needed)>top-bottom:e.WARNINGS.append({'kind':'solution_overflow','task':card['number'],'needed':sum(needed),'available':top-bottom})
    slack=max(0,(top-bottom-sum(needed))/len(steps))
    for i,(s,h) in enumerate(zip(steps,needed),1):
        end=e.section_heading(c,s['heading'],i,39,top,972,P,size=29)
        textend=e.paragraph(c,s['text'],39,end,972,limit=h-45-12,size=body_size,minsize=body_size,leading=body_size*1.25,color=P['ink'])
        top-=h+slack
        if i<len(steps):e.rule(c,39,top+5,972,P)

def coding_steps(c,card,top):
    top=e.section_heading(c,'Перебираем и проверяем все дороги',1,39,top,972,P,size=29)
    text='Перебираем все 5040 назначения номеров буквам. Сохраняем полное совпадение рёбер графа и таблицы, без учёта длин.'
    top=e.paragraph(c,text,39,top,972,size=24,leading=30,color=P['ink'])-12
    code=card['code']
    lines=code.splitlines();longest=max(map(len,lines))
    size=20
    ch=len(lines)*size*1.3+24
    # Use the established limited syntax palette, but an explicit readable size.
    e.rounded(c,39,top-ch,972,ch,P,pale=False)
    from pygments import lex
    from pygments.lexers import PythonLexer
    from pygments.token import Token
    px,py=54,top-14-size
    for token,val in lex(code,PythonLexer()):
        color='#145bea' if token in Token.Keyword else '#0a8a79' if token in Token.Literal.String or token in Token.Literal.Number else P['ink']
        chunks=val.split('\n')
        for j,s in enumerate(chunks):
            if s:e.text(c,s,px,py,size,'mono',color);px+=e.width(s,'mono',size)
            if j<len(chunks)-1:px=54;py-=size*1.3
    top-=ch+12
    top=e.section_heading(c,'Два соответствия — один ответ',2,39,top,972,P,size=29)
    e.text(c,'А   Б   В   Г   Д   Е   К',42,top-22,23,'mono',P['accent'])
    e.text(c,'3   5   6   2   7   4   1',42,top-51,23,'mono',P['ink'])
    e.text(c,'5   3   6   2   7   4   1',42,top-80,23,'mono',P['ink'])
    e.paragraph(c,'Меняются только А и Б.\nВ обоих случаях В = П6, Е = П4.\nЧитаем клетку П6–П4: 20 км.',590,top,420,size=24,minsize=23,color=P['ink'])
    if top-89<155:e.WARNINGS.append({'kind':'code_card_overflow','task':38,'bottom':top-89})

def render(cards):
    OUT.mkdir(exist_ok=True)
    e.WARNINGS=[]
    path=OUT/'informatics_solutions_6.pdf'
    c=canvas.Canvas(str(path),pagesize=(1050,1500),pageCompression=1)
    c.setTitle('Информатика: задачи 1–6, полный разбор')
    c.setAuthor('Учебные карточки')
    for i,card in enumerate(cards,1):
        e.fill(c,e.BG);c.rect(0,0,1050,1500,stroke=0,fill=1)
        question=QUESTIONS[card['number']]
        titlecard={'title':TITLES[card['number']],'subtitle':question,'label':'ИНФОРМАТИКА · РАЗБОР ЗАДАЧ'}
        top=e.title_block(c,titlecard,i,len(cards),P,'informatics')
        top=hero(c,card,top)
        e.rule(c,39,top+8,972,P)
        if card['number']==38:coding_steps(c,card,top-9)
        else:ordinary_steps(c,card,top-9)
        footer(c,card)
        c.showPage()
    c.save()
    pngs=[]
    with fitz.open(path) as doc:
        for i,(page,card) in enumerate(zip(doc,cards),1):
            name=OUT/f'{i:02d}_task_{card["number"]}.png'
            page.get_pixmap(alpha=False).save(name);pngs.append(str(name))
    e.make_contact_sheet(pngs,OUT/'preview.png',columns=3,thumb_width=350)
    (OUT/'layout_validation.json').write_text(json.dumps(e.WARNINGS,ensure_ascii=False,indent=2))
    print(json.dumps({'pdf':str(path),'pages':len(cards),'warnings':e.WARNINGS},ensure_ascii=False,indent=2))

if __name__=='__main__':
    data=json.loads((ROOT/'solutions.json').read_text())
    render(data)
