"""Vector educational-card renderer. Coordinates use 1050 × 1500 design units.

Public API: render_deck(cards, pdf_path, subject), make_contact_sheet(pngs, path).
Diagram callbacks: DIAGRAMS[name] = callable(canvas, x, y, w, h, palette, card)
(x,y) is lower-left, ReportLab coordinates. Keep drawings inside their rectangle.
"""
from pathlib import Path
import os, re, io, json, math, html, hashlib
from functools import lru_cache
os.environ.setdefault('MPLCONFIGDIR','/tmp/cards-matplotlib')
import matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['mathtext.fontset']='stix'
matplotlib.rcParams['savefig.transparent']=True
from matplotlib import mathtext
from matplotlib.font_manager import FontProperties
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor, Color
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from pygments import lex
from pygments.lexers import PythonLexer
from pygments.token import Token
import fitz
from PIL import Image, ImageDraw, ImageFont

W,H=1050,1500
M=39
BG='#fdfcf7'
FONTS={'sans':'/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','sansb':'/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf','serif':'/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf','serifb':'/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf','mono':'/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'}
for name,path in FONTS.items(): pdfmetrics.registerFont(TTFont(name,path))
pdfmetrics.registerFontFamily('sans',normal='sans',bold='sansb',italic='sans',boldItalic='sansb')
pdfmetrics.registerFontFamily('serif',normal='serif',bold='serifb',italic='serif',boldItalic='serifb')
PALETTES={'physics':{'ink':'#202020','accent':'#07562a','pale':'#edf3e7','line':'#176438','title':'serifb','heading':'serifb'},'informatics':{'ink':'#152031','accent':'#006b68','pale':'#e9f7f1','line':'#40988d','title':'sansb','heading':'sansb'}}
DIAGRAMS={}
WARNINGS=[]

def fill(c,color): c.setFillColor(HexColor(color))
def stroke(c,color): c.setStrokeColor(HexColor(color))
def rule(c,x,y,w,p):
    stroke(c,p['line']); c.setLineWidth(1.3);c.line(x,y,x+w,y)
def text(c,s,x,y,size=25,font='sans',color='#202020'):
    fill(c,color);c.setFont(font,size);c.drawString(x,y,str(s))
def width(s,font,size):return pdfmetrics.stringWidth(s,font,size)
def wrapped_lines(s,font,size,w):
    lines=[]
    for segment in str(s).split('\n'):
        line=''
        for word in segment.split():
            candidate=(line+' '+word).strip()
            if line and width(candidate,font,size)>w:lines.append(line);line=word
            else:line=candidate
        lines.append(line)
    return lines

def paragraph(c,s,x,top,w,limit=None,size=25,color='#202020',bold=False,minsize=21,leading=None):
    if not s:return top
    ss=html.escape(str(s)).replace('\n','<br/>')
    ss=re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',ss)
    font='sansb' if bold else 'sans'
    actual=size
    while True:
        style=ParagraphStyle('body',fontName=font,fontSize=actual,leading=leading or actual*1.35,textColor=HexColor(color),spaceAfter=0)
        para=Paragraph(ss,style)
        _,h=para.wrap(w,10000)
        if limit is None or h<=limit or actual<=minsize:break
        actual-=0.5
    if limit is not None and h>limit+1:
        WARNINGS.append({'kind':'paragraph_overflow','text':str(s)[:100],'height':round(h,1),'allowed':limit})
    para.drawOn(c,x,top-h)
    return top-h

def rounded(c,x,y,w,h,p,pale=True):
    stroke(c,p['line']);fill(c,p['pale'] if pale else BG);c.setLineWidth(1.2);c.roundRect(x,y,w,h,9,stroke=1,fill=1)

@lru_cache(maxsize=512)
def math_image(tex):
    tex=str(tex).strip().strip('$')
    tex=tex.replace('\\text{','\\mathrm{').replace('\\dfrac','\\frac').replace('\\tfrac','\\frac')
    buffer=io.BytesIO()
    try:
        mathtext.math_to_image('$'+tex+'$',buffer,prop=FontProperties(size=30),dpi=180,format='png',color='#202020')
    except Exception as e:
        WARNINGS.append({'kind':'math_error','formula':tex,'error':str(e)})
        raise ValueError('Cannot render formula '+tex) from e
    buffer.seek(0); img=Image.open(buffer).convert('RGBA');a=img.getchannel('A')
    box=a.getbbox()
    if box:img=img.crop(box)
    return img

def formula(c,tex,x,top,w,size=36,boxed=True,p=None,maxh=112):
    p=p or PALETTES['physics']
    img=math_image(tex);iw,ih=img.size
    # math_to_image 30pt @180dpi -> 75px em, convert to design fontsize
    sc=size/75;dw,dh=iw*sc,ih*sc
    fac=min(1,(w-32)/max(1,dw),(maxh-28)/max(1,dh));dw*=fac;dh*=fac
    h=max(64,dh+28)
    if boxed:rounded(c,x,top-h,w,h,p)
    c.drawImage(ImageReader(img),x+(w-dw)/2,top-h+(h-dh)/2,width=dw,height=dh,mask='auto')
    return top-h

def formulas(c,fs,x,top,w,p,size=35,maxheight=None):
    if isinstance(fs,str):fs=[fs]
    for index,f in enumerate(fs or []):
        if isinstance(f,dict):
            if f.get('label'):top=paragraph(c,f['label'],x,top,w,size=22,color=p['accent'],bold=True)-9
            tex=f.get('tex',f.get('formula',''))
        else:tex=f
        top=formula(c,tex,x,top,w,size=size,p=p)
        if index<len(fs)-1:top-=13
    return top

def code_block(c,code,x,top,w,p,maxheight=235):
    lines=str(code).splitlines() or ['']
    longest=max(len(z.expandtabs(4)) for z in lines)
    size=min(24,(w-32)/(max(1,longest)*.603), (maxheight-28)/(len(lines)*1.35))
    if size<18: WARNINGS.append({'kind':'code_too_small','size':round(size,1),'longest_line':longest,'code':str(code)[:100]})
    size=max(18,size);lineh=size*1.35;h=len(lines)*lineh+30
    rounded(c,x,top-h,w,h,p,pale=False)
    px=x+15;py=top-15-size
    for token,value in lex(code,PythonLexer()):
        color= '#145bea' if token in Token.Keyword else '#0a8a79' if token in Token.Literal.Number else '#0a8a79' if token in Token.Literal.String else '#77848b' if token in Token.Comment else p['ink']
        chunks=value.split('\n')
        for j,ch in enumerate(chunks):
            if ch:text(c,ch,px,py,size,'mono',color);px+=width(ch,'mono',size)
            if j<len(chunks)-1:px=x+15;py-=lineh
    return top-h

def display_focus(c,display,x,top,w,h,p):
    """Large, unframed typographic concept in the right half of a section."""
    value=str(display)
    actual=35
    while True:
        style=ParagraphStyle('focus',fontName='sansb',fontSize=actual,leading=actual*1.36,textColor=HexColor(p['accent']),alignment=1)
        para=Paragraph(html.escape(value).replace('\n','<br/>'),style)
        _,ph=para.wrap(w-20,10000)
        if ph<=h-12 or actual<=25:break
        actual-=.5
    if ph>h-10:WARNINGS.append({'kind':'display_overflow','text':value[:100],'height':round(ph,1),'allowed':h})
    para.drawOn(c,x+10,top-(h-ph)/2-ph)
    return top-(h-ph)/2-ph

def arrow(c,x1,y1,x2,y2,color='#07562a',lw=3,head=11):
    stroke(c,color);fill(c,color);c.setLineWidth(lw);c.line(x1,y1,x2,y2)
    a=math.atan2(y2-y1,x2-x1);path=c.beginPath();path.moveTo(x2,y2)
    path.lineTo(x2-head*math.cos(a-.45),y2-head*math.sin(a-.45));path.lineTo(x2-head*math.cos(a+.45),y2-head*math.sin(a+.45));path.close();c.drawPath(path,fill=1,stroke=0)

def circle_diagram(c,x,y,w,h,p,card):
    cx=x+w*.48;cy=y+h*.46;r=min(w*.19,h*.35)
    stroke(c,p['line']);c.setLineWidth(2);c.circle(cx,cy,r,stroke=1,fill=0)
    phi=.72;px=cx+r*math.cos(phi);py=cy+r*math.sin(phi)
    c.setDash(6,5);c.line(cx,cy,px,py);c.setDash()
    fill(c,p['ink']);c.circle(cx,cy,4,fill=1);c.circle(px,py,6,fill=1)
    arrow(c,px,py,px-r*.7*math.sin(phi),py+r*.7*math.cos(phi),p['accent'])
    arrow(c,px,py,cx+(px-cx)*.35,cy+(py-cy)*.35,p['accent'])
    text(c,'O',cx-24,cy-25,25,'serif',p['ink']);text(c,'R',cx+17,cy+13,26,'serif',p['ink'])
    text(c,'v',px-r*.7*math.sin(phi)-26,py+r*.7*math.cos(phi)+5,32,'serif',p['accent'])
    text(c,'aₙ',cx+r*.1,cy+r*.4,25,'sans',p['accent'])
    paragraph(c,'Скорость — по касательной.\nНормальное ускорение — к центру.',x+w*.7,y+h*.65,w*.28,size=23,color=p['accent'])
DIAGRAMS['circle']=circle_diagram

def graph_diagram(c,x,y,w,h,p,card):
    coords=[(.14,.5),(.39,.85),(.65,.75),(.86,.45),(.57,.17),(.28,.17)]
    pts=[(x+a*w,y+b*h) for a,b in coords]
    for i,j,n in [(0,1,3),(0,5,7),(1,2,4),(1,5,2),(2,3,5),(2,4,1),(3,4,6),(4,5,3)]:
        ax,ay=pts[i];bx,by=pts[j];stroke(c,p['line']);c.setLineWidth(2.5);c.line(ax,ay,bx,by)
        fill(c,BG);c.roundRect((ax+bx)/2-12,(ay+by)/2-8,25,25,4,fill=1,stroke=0)
        text(c,n,(ax+bx)/2-6,(ay+by)/2-2,20,'sans',p['ink'])
    for i,(px,py) in enumerate(pts):
        fill(c,p['pale']);stroke(c,p['accent']);c.circle(px,py,21,fill=1,stroke=1)
        text(c,chr(65+i),px-10,py-9,24,'sansb',p['accent'])
DIAGRAMS['graph']=graph_diagram

def draw_diagram(c,key,x,y,w,h,p,card):
    if callable(key):key(c,x,y,w,h,p,card)
    elif key in DIAGRAMS:DIAGRAMS[key](c,x,y,w,h,p,card)
    else:
        WARNINGS.append({'kind':'missing_diagram','diagram':str(key),'title':card.get('title')})
        # Blank is better than inventing a diagram for the task.


def title_block(c,card,index,count,p,subject):
    label=card.get('label') or ('МЕХАНИКА' if subject=='physics' else 'ИНФОРМАТИКА')
    text(c,label,M,H-42,23,'serif' if subject=='physics' else 'sans',p['ink'])
    counter=f'{index:02d}/{count:02d}';text(c,counter,W-M-width(counter,'sansb',25),H-42,25,'sansb',p['accent'])
    rule(c,M,H-62,W-2*M,p)
    s=card['title'];explicit='\n' in s;size=73 if subject=='physics' else 72
    while size>=44:
        lines=s.split('\n') if explicit else wrapped_lines(s,p['title'],size,W-2*M)
        if len(lines)<=3 and all(width(z,p['title'],size)<=W-2*M for z in lines):break
        size-=1
    top=H-94
    for i,line in enumerate(lines):
        text(c,line,M,top-size*.76,size,p['title'],p['accent'] if i==len(lines)-1 else p['ink'])
        top-=size*1.05
    top-=13
    sub=card.get('subtitle','')
    top=paragraph(c,sub,M,top,W-2*M,size=25,minsize=23,color=p['ink'])-22
    return top

def section_heading(c,heading,num,x,top,w,p,size=30):
    heading=re.sub(r'^\d{1,2}\s+', '', str(heading))
    numw=61
    fill(c,p['pale']);c.roundRect(x,top-38,numw,41,8,fill=1,stroke=0)
    text(c,f'{num:02d}',x+10,top-30,30,'sansb',p['ink'])
    stroke(c,p['line']);c.setLineWidth(1.5);c.line(x+numw+16,top+2,x+numw+16,top-39)
    lines=wrapped_lines(heading,p['heading'],size,w-numw-45)
    if len(lines)>2:
        size=26;lines=wrapped_lines(heading,p['heading'],size,w-numw-45)
    for i,line in enumerate(lines):text(c,line,x+numw+35,top-29-i*size*1.16,size,p['heading'],p['accent'])
    return top-max(49,len(lines)*size*1.16+12)

def sections_layout(c,card,top,bottom,p,subject):
    secs=card.get('sections',[])
    diagram=card.get('diagram')
    if diagram:
        dh=min(255,max(180,(top-bottom)*.25))
        draw_diagram(c,diagram,M,top-dh,W-2*M,dh,p,card);top-=dh+10
        rule(c,M,top,W-2*M,p);top-=16
    if not secs:return
    available=top-bottom-(len(secs)-1)*10
    def ph(value,size,w):
        if not value:return 0
        pp=Paragraph(html.escape(str(value)).replace('\n','<br/>'),ParagraphStyle('measure',fontName='sans',fontSize=size,leading=size*1.35))
        return pp.wrap(w,10000)[1]
    # Reserve the actual minimum content height first, including worked examples.
    minimum=[];ideal=[]
    for sec in secs:
        fs=sec.get('formula',sec.get('formulas',[]));fc=1 if isinstance(fs,str) else len(fs or [])
        code=sec.get('code','');hasright=bool(fs or code or sec.get('diagram') or sec.get('display'))
        lw=(W-2*M)*.47-12 if hasright else W-2*M
        body=sec.get('body','');example=sec.get('example','')
        heading=re.sub(r'^\d{1,2}\s+','',sec.get('heading',''))
        hs=32 if subject=='informatics' else 30
        hh=max(49,len(wrapped_lines(heading,p['heading'],hs,W-2*M-106))*hs*1.16+12)
        bs=28 if subject=='informatics' else 24;bm=23 if subject=='informatics' else 21
        leftmin=ph(body,bm,lw)+(12+ph(example,21,lw) if example else 0)
        leftideal=ph(body,bs,lw)+(12+ph(example,22,lw) if example else 0)
        rmin=fc*64+max(0,fc-1)*13;rideal=fc*85+max(0,fc-1)*13
        if code:
            ln=len(code.splitlines());longest=max(map(len,code.splitlines()))
            cs=min(24,((W-2*M)*.53-27-32)/(max(1,longest)*.603))
            rideal=ln*cs*1.35+30;rmin=ln*18*1.35+30
        minimum.append(hh+max(leftmin,rmin)+15)
        ideal.append(hh+max(leftideal,rideal)+15)
    if available>=sum(ideal):
        heights=[z+(available-sum(ideal))/len(secs) for z in ideal]
    elif available>=sum(minimum):
        slack=available-sum(minimum);demands=[max(0,b-a) for a,b in zip(minimum,ideal)]
        heights=[a+slack*d/max(1,sum(demands)) for a,d in zip(minimum,demands)]
    else:
        heights=[available*z/sum(minimum) for z in minimum]
    if subject=='physics':
        weights=[]
        for sec in secs:
            fs=sec.get('formula',sec.get('formulas',[]));fc=1 if isinstance(fs,str) else len(fs or [])
            ln=len(str(sec.get('code','')).splitlines())
            weights.append(max(1,len(sec.get('body',''))/260+fc*.45+ln*.12))
        heights=[available*z/sum(weights) for z in weights]
    for i,sec in enumerate(secs):
        sh=heights[i]
        content_top=section_heading(c,sec.get('heading',''),i+1,M,top,W-2*M,p,size=(32 if subject=='informatics' else 30) if len(secs)<=3 else 28)
        content_bottom=top-sh+15
        innerh=content_top-content_bottom
        body=sec.get('body','');fs=sec.get('formula',sec.get('formulas'));code=sec.get('code');diag=sec.get('diagram');display=sec.get('display');ex=sec.get('example')
        hasright=bool(fs or code or diag or display)
        if hasright:
            lw=(W-2*M)*.47;rx=M+lw+27;rw=W-M-rx
            stroke(c,p['line']);c.setLineWidth(1.1);c.line(rx-14,content_top,rx-14,content_bottom)
            body_size=28 if subject=='informatics' else 24
            body_min=23 if subject=='informatics' else 21
            ex_size=22
            while ph(body,body_size,lw-12)+(12+ph(ex,ex_size,lw-12) if ex else 0)>innerh and (body_size>body_min or ex_size>21):
                if body_size>body_min:body_size-=.5
                elif ex_size>21:ex_size-=.5
            bend=paragraph(c,body,M,content_top,lw-12,limit=innerh,size=body_size,minsize=body_min,color=p['ink'])
            if ex:bend=paragraph(c,ex,M,bend-12,lw-12,limit=bend-12-content_bottom,size=ex_size,minsize=21,color=p['accent'])
            rt=content_top
            if diag:draw_diagram(c,diag,rx,content_bottom,rw,innerh,p,card)
            elif code:rt=code_block(c,code,rx,rt,rw,p,maxheight=innerh)
            elif display:rt=display_focus(c,display,rx,rt,rw,innerh,p)
            else:rt=formulas(c,fs,rx,rt,rw,p,size=40 if subject=='physics' else 34)
            if rt<content_bottom-2:WARNINGS.append({'kind':'section_overflow','title':card['title'],'section':i+1,'excess':round(content_bottom-rt,1)})
        else:
            paragraph(c,body,M,content_top,W-2*M,limit=innerh,size=28 if subject=='informatics' else 25,minsize=23 if subject=='informatics' else 22,color=p['ink'])
        top-=sh
        if i<len(secs)-1:rule(c,M,top,W-2*M,p);top-=10


def columns_layout(c,card,top,bottom,p):
    diagram=card.get('diagram','circle');dh=min(450,(top-bottom)*.47)
    draw_diagram(c,diagram,M,top-dh,W-2*M,dh,p,card);top-=dh+20
    secs=card.get('sections',[]);cw=(W-2*M)/max(1,len(secs))
    for i,sec in enumerate(secs):
        x=M+i*cw+8;w=cw-29
        if i:stroke(c,p['line']);c.setLineWidth(1.4);c.line(x-16,top,x-16,bottom)
        ht=paragraph(c,sec.get('heading',''),x,top,w,size=28,color=p['accent'],bold=True,minsize=25)-18
        ht=paragraph(c,sec.get('body',''),x,ht,w,size=23,minsize=22,color=p['ink'])-17
        ht=formulas(c,sec.get('formula',sec.get('formulas')),x,ht,w,p,size=37)
        if sec.get('example'):ht=paragraph(c,sec['example'],x,ht,w,size=22,color=p['ink'])
        if ht<bottom:WARNINGS.append({'kind':'column_overflow','title':card['title'],'column':i+1,'excess':bottom-ht})


def takeaway(c,card,p):
    y=33;h=143;x=32;w=W-64
    rounded(c,x,y,w,h,p)
    split=x+195
    stroke(c,p['accent']);c.setLineWidth(3);c.line(split,y+17,split,y+h-17)
    take_label='Главное:' if p['title']=='sansb' else 'Главное'
    take_size=min(39,155/max(1,width(take_label,p['heading'],1)))
    text(c,take_label,x+20,y+h/2-take_size*.36,take_size,p['heading'],p['accent'])
    paragraph(c,card.get('takeaway',''),split+24,y+h-21,w-244,limit=h-40,size=25,minsize=20,color=p['ink'])

def render_card(c,card,index,count,subject):
    p=PALETTES[subject];fill(c,BG);c.rect(0,0,W,H,fill=1,stroke=0)
    top=title_block(c,card,index,count,p,subject)
    # Keep a compact final worked example independent of the takeaway.
    example=card.get('example');bottom=200+(87 if example else 0)
    if card.get('layout')=='columns' and subject=='physics':columns_layout(c,card,top,bottom,p)
    else:sections_layout(c,card,top,bottom,p,subject)
    if example:
        rule(c,M,271,W-2*M,p)
        paragraph(c,example,M,257,W-2*M,limit=62,size=23,minsize=20,color=p['ink'])
    takeaway(c,card,p)

def render_deck(cards,path,subject='physics',png_dir=None):
    """Create vector PDF and exact 1050×1500 PNG pages, return generated paths."""
    global WARNINGS
    WARNINGS=[];path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    c=canvas.Canvas(str(path),pagesize=(W,H),pageCompression=1)
    c.setTitle('Карточки: '+('физика' if subject=='physics' else 'информатика'));c.setAuthor('Учебные карточки')
    for i,card in enumerate(cards,1):render_card(c,card,i,len(cards),subject);c.showPage()
    c.save()
    png_dir=Path(png_dir or path.parent/(path.stem+'_png'));png_dir.mkdir(parents=True,exist_ok=True)
    doc=fitz.open(path);pngs=[]
    for i,page in enumerate(doc,1):
        pp=png_dir/f'{i:02d}.png';page.get_pixmap(matrix=fitz.Matrix(1,1),alpha=False).save(pp);pngs.append(str(pp))
    log=path.with_suffix('.validation.json');log.write_text(json.dumps({'pages':len(cards),'warnings':WARNINGS},ensure_ascii=False,indent=2),encoding='utf-8')
    return {'pdf':str(path),'pngs':pngs,'validation':str(log),'warnings':list(WARNINGS)}

def make_contact_sheet(pngs,path,columns=4,thumb_width=270):
    rows=math.ceil(len(pngs)/columns);th=int(thumb_width*H/W);gap=16
    sheet=Image.new('RGB',(columns*(thumb_width+gap)+gap,rows*(th+35+gap)+gap),'#e8e8e3')
    font=ImageFont.truetype(FONTS['sans'],18)
    d=ImageDraw.Draw(sheet)
    for i,pp in enumerate(pngs):
        im=Image.open(pp).convert('RGB');im.thumbnail((thumb_width,th),Image.Resampling.LANCZOS)
        x=gap+(i%columns)*(thumb_width+gap);y=gap+(i//columns)*(th+35+gap)
        sheet.paste(im,(x,y));d.text((x,y+th+5),f'{i+1:02d}',fill='#202020',font=font)
    sheet.save(path);return str(path)

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('output');ap.add_argument('--subject',default='physics',choices=PALETTES);args=ap.parse_args()
    data=json.loads(Path(args.input).read_text(encoding='utf-8'));cards=data.get('cards',data) if isinstance(data,dict) else data
    result=render_deck(cards,args.output,args.subject);print(json.dumps(result,ensure_ascii=False))
